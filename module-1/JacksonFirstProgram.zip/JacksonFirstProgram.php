
<!DOCTYPE html>
<html>
<head>
    <title>My First PHP Program</title>
</head>
<body>

<h1>Welcome to My First PHP Page</h1>


<?php
echo "Hello, my name is Jackson.<br>";
?>

<?php
$date = date("Y-m-d");
echo "Today's date is: " . $date;
?>

</body>
</html>